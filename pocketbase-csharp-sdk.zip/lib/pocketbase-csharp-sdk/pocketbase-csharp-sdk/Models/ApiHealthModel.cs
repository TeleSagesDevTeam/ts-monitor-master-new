﻿namespace pocketbase_csharp_sdk.Models
{
    public class ApiHealthModel
    {
        public int? Code { get; set; }
        public string? Message { get; set; }
    }
}
