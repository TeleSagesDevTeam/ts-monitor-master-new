﻿namespace pocketbase_csharp_sdk.Models.Files
{
    public abstract class BaseFile
    {
        public string? FieldName { get; set; }
        public string? FileName { get; set; }
    }
}
