﻿namespace pocketbase_csharp_sdk.Models.Auth
{
    public class UserAuthModel : RecordAuthModel<UserModel>
    {
    }
}
