﻿namespace pocketbase_csharp_sdk.Models
{
    public class UserModel : BaseAuthModel
    {
        public string? Avatar { get; set; }
        
    }
}
