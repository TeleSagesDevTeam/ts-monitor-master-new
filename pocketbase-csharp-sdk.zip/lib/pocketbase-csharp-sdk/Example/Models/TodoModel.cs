﻿using pocketbase_csharp_sdk.Models;

namespace Example.Models
{
    public class TodoModel : BaseModel
    {
        public string? Name { get; set; }
    }
}
